import json
import sys
from pathlib import Path

import pytest
import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from immc_power_capacity.app import run
from immc_power_capacity.core import ValidationError, assess_site, land_capacity, water_budget


@pytest.fixture
def site():
    return yaml.safe_load((ROOT / "examples/q1_site.yaml").read_text(encoding="utf-8"))


def test_demo(tmp_path):
    output = tmp_path / "result.json"
    report = run(ROOT / "examples/q1_site.yaml", output)
    assert json.loads(output.read_text(encoding="utf-8")) == report
    assert report["P_max_mw_it"] == 130
    assert report["winners"] == ["燃气配干冷园区"]
    assert report["excluded"][0]["online_year"] == 2030
    assert [row["binding"] for row in report["scenarios"]] == [["电力"], ["电力"], ["水"], ["土地"]]
    assert report["scenarios"][-1]["breakdown"]["facility_mw"] == 168
    wet_gas = report["scenarios"][2]
    expected = (150 + 0.78 * 108) / (1.5 + 0.78 * 1.2)
    assert wet_gas["P_mw_it"] == pytest.approx(expected)
    assert wet_gas["self_generation_used_mw"] == pytest.approx(1.2 * expected - 108)
    assert wet_gas["generation_water_m3_h"] == pytest.approx(150 - 1.5 * expected)
    assert wet_gas["Q_net_m3_h"] == pytest.approx(1.5 * expected)
    assert report["scenarios"][-1]["self_generation_used_mw"] == pytest.approx(48)
    assert report["water"]["limits_m3_h"] == {"source": 400, "stress": 150, "policy": 180}


def test_minimal_config():
    data = yaml.safe_load((ROOT / "examples/q1_minimal.yaml").read_text(encoding="utf-8"))
    report = assess_site(data)
    assert report["P_max_mw_it"] == 100
    assert report["scenarios"][0]["online_year"] == report["assessment_year"]
    assert report["scenarios"][0]["P_W_mw_it"] == 120
    assert report["scenarios"][0]["P_L_mw_it"] == 160


def test_csv_online_year_is_optional(tmp_path):
    path = tmp_path / "grid.csv"
    path.write_text(
        "site,assessment_year,period_note,service_level,P_grid_mw,k_factor,"
        "water_basis,water_policy_m3_h,water_wue_l_per_kwh_it,"
        "land_effective_ha,land_ha_per_mw_it,scenario_name,scenario_type\n"
        "演示场址,2028,单个设计日,正常运营且持续满载,120,1.2,"
        "consumption,180,1.5,160,1,纯电网,grid\n",
        encoding="utf-8",
    )
    report = run(path)
    assert report["P_max_mw_it"] == 100
    assert report["scenarios"][0]["online_year"] == 2028
    assert report["excluded"] == []


def test_csv_input_matches_yaml_example():
    report = run(ROOT / "examples/q1_site.csv")
    assert report["P_max_mw_it"] == 130
    assert [row["name"] for row in report["scenarios"]] == [
        "纯电网",
        "光储",
        "燃气配湿冷园区",
        "燃气配干冷园区",
    ]
    wet_gas = report["scenarios"][2]
    expected = (180 + 0.78 * 108) / (1.5 + 0.78 * 1.2)
    assert wet_gas["P_W_mw_it"] == pytest.approx(expected)
    assert wet_gas["generation_water_m3_h"] == pytest.approx(180 - 1.5 * expected)


def test_csv_can_choose_generation_land_option():
    report = run(ROOT / "examples/q1_site_ae_options.csv")
    row = report["scenarios"][0]
    assert report["P_max_mw_it"] == 140
    assert row["generation_land_ha"] == 10
    assert row["generation_land_source"] == "options"
    assert row["generation_land_required_ha"] == 8
    assert len(row["generation_land_candidates"]) == 2


def test_generation_land_must_cover_resource_area(site):
    site["scenarios"] = [{
        "name": "用地不足的光储",
        "type": "solar",
        "online_year": 2028,
        "generation_land_options_ha": [10],
        "area_km2": 0.2,
        "density_mw_per_km2": 100,
        "net_output_mw": [20, 0],
        "dt_hours": 1,
    }]
    row = assess_site(site)["scenarios"][0]
    assert row["generation_land_ha"] == 10
    assert row["generation_land_required_ha"] == 10
    assert row["generation_land_capacity_capped"] is True
    assert row["P_E_mw_it"] == pytest.approx(90)


def test_external_generation_land_is_not_deducted(site):
    site["scenarios"] = [{
        "name": "外部电源",
        "type": "grid",
        "online_year": 2028,
        "generation_land_in_site": False,
    }]
    row = assess_site(site)["scenarios"][0]
    assert row["generation_land_ha"] == 0
    assert row["generation_land_source"] == "external"
    assert row["P_L_mw_it"] == 150


def test_external_wind_land_is_not_deducted(site):
    site["P_grid_mw"] = 0
    site["scenarios"] = [{
        "name": "外部风电",
        "type": "wind",
        "online_year": 2028,
        "generation_land_in_site": False,
        "area_km2": 1,
        "density_mw_per_km2": 100,
        "alpha": 0.2,
    }]
    row = assess_site(site)["scenarios"][0]
    assert row["generation_land_ha"] == 0
    assert row["generation_land_source"] == "external"
    assert row["generation_land_required_ha"] == 100
    assert row["P_L_mw_it"] == 150
    assert row["P_E_mw_it"] == pytest.approx(100 / 6)


def test_wind_installed_capacity_scales_with_land(site):
    site["P_grid_mw"] = 0
    site["scenarios"] = [{
        "name": "受限风电",
        "type": "wind",
        "online_year": 2028,
        "installed_mw": 100,
        "area_km2": 1,
        "density_mw_per_km2": 100,
        "alpha": 0.2,
        "generation_land_options_ha": [10],
    }]
    row = assess_site(site)["scenarios"][0]
    assert row["generation_land_ha"] == 10
    assert row["generation_land_required_ha"] == 10
    assert row["generation_land_capacity_capped"] is True
    assert row["P_E_mw_it"] == pytest.approx(10 / 6)


def test_direct_limit_overrides_are_marked(site):
    site["scenarios"] = [{
        "name": "直接结果",
        "type": "grid",
        "online_year": 2028,
        "direct_P_E_mw_it": 100,
        "direct_P_W_mw_it": 80,
        "direct_P_L_mw_it": 70,
    }]
    row = assess_site(site)["scenarios"][0]
    assert row["P_mw_it"] == 70
    assert row["binding"] == ["土地"]
    assert row["value_source"] == {
        "P_E": "direct",
        "P_W": "direct",
        "P_L": "direct",
    }


def test_seasonal_wue_weighting():
    water = {
        "basis": "withdrawal",
        "source_m3_h": 100,
        "wue_summer_l_per_kwh_it": 2,
        "wue_winter_l_per_kwh_it": 1,
        "summer_hours": 6,
        "winter_hours": 6,
    }
    assert water_budget(water)["wue_l_per_kwh_it"] == pytest.approx(1.5)


@pytest.mark.parametrize(("budget", "capacity"), [
    ({"source_m3_h": 100}, 50),
    ({"period_budget_m3": 1200}, 80),
    ({"period_budget_m3": 1200, "source_m3_h": 100}, 50),
    ({"summer_limit_m3_h": 160, "winter_limit_m3_h": 25}, 50),
])
def test_constant_load_obeys_each_water_budget(site, budget, capacity):
    site["scenarios"] = [site["scenarios"][0]]
    site["water"] = dict(basis="withdrawal", wue_summer_l_per_kwh_it=2,
                         wue_winter_l_per_kwh_it=0.5, summer_hours=6, winter_hours=6, **budget)
    row = assess_site(site)["scenarios"][0]
    assert row["P_mw_it"] == pytest.approx(capacity)
    assert all(check["water_used_m3_h"] <= check["limit_m3_h"] for check in row["water_checks"])


@pytest.mark.parametrize(("budget", "capacity", "water_limit"), [
    (0, 0, 0), (10, 10, 10), (50, 50, None), (60, 50, None),
])
def test_zero_cooling_wue_still_charges_for_generation(site, budget, capacity, water_limit):
    site.update(P_grid_mw=0, k_factor=1, scenarios=[
        dict(type="gas", name="gas", units=1, unit_net_mw=50, generation_water_l_per_kwh=1)])
    site["water"] = dict(basis="withdrawal", wue_l_per_kwh_it=0, source_m3_h=budget)
    row = assess_site(site)["scenarios"][0]
    assert row["P_mw_it"] == capacity
    assert row["P_W_mw_it"] == water_limit
    assert row["generation_water_m3_h"] == capacity


def test_grid_conversion_and_tied_winners(site):
    del site["P_grid_mw"]
    site.update(P_grid_mva=120, power_factor=0.9)
    original = site["scenarios"][0]
    site["scenarios"] = [original, dict(original, name="第二接入方案")]
    report = assess_site(site)
    assert report["P_max_mw_it"] == 90
    assert len(report["winners"]) == 2
    assert "初筛" in report["grid_basis"]


def test_isolated_and_grid_wind(site):
    site["P_grid_mw"] = 0
    wind = dict(type="wind", name="风电", online_year=2028, alpha=0.2, installed_mw=120)
    site["scenarios"] = [wind]
    assert assess_site(site)["P_max_mw_it"] == 20
    site["P_grid_mw"] = 108
    with pytest.raises(ValidationError, match="同期"):
        assess_site(site)
    del wind["alpha"]
    wind["net_output_mw"] = [24, 12]
    assert assess_site(site)["scenarios"][0]["P_E_mw_it"] == 100


def test_land_and_year(site):
    site["assessment_year"] = 2025
    with pytest.raises(ValidationError, match="没有"):
        assess_site(site)
    assert land_capacity(dict(effective_ha=10, fixed_it_ha=10, ha_per_mw_it=1))["P_L_mw_it"] == 0


def test_invalid_online_year_is_rejected(site):
    site["scenarios"][0]["online_year"] = 2028.5
    with pytest.raises(ValidationError, match="online_year"):
        assess_site(site)


def test_q1_rejects_unknown_type(site):
    site["scenarios"] = [{
        "name": "不在正稿内的方案",
        "type": "unknown",
        "online_year": 2028,
    }]
    with pytest.raises(ValidationError, match="正稿 Q1"):
        assess_site(site)


def test_removed_fields_are_not_silently_ignored(site):
    site["C_PCC_mw"] = 150
    with pytest.raises(ValidationError, match="C_PCC_mw"):
        assess_site(site)
    del site["C_PCC_mw"]
    site["land"]["generation_share"] = 0.1
    with pytest.raises(ValidationError, match="generation_share"):
        assess_site(site)


def test_q1_combined_battery(site):
    site["scenarios"] = [{
        "name": "风光共用电池",
        "type": "combined_battery",
        "online_year": 2028,
        "installed_mw": 230,
        "dt_hours": 1,
        "supply_series_mw": [20, 0],
        "battery": {
            "C_max_mw": 10,
            "D_max_mw": 10,
            "E_usable_mwh": 10,
        },
    }]
    row = assess_site(site)["scenarios"][0]
    assert row["P_E_mw_it"] == pytest.approx(98.33333333333334)
    assert row["binding"] == ["电力"]


@pytest.mark.parametrize("water", [
    {"basis": "withdrawal"},
    {"basis": "consumption", "river_m3_h": 1, "eco_m3_h": 0, "other_m3_h": 0},
    {"basis": "withdrawal", "source_m3_h": 1, "river_m3_h": 2, "eco_m3_h": 0, "other_m3_h": 0},
    {"basis": "withdrawal", "policy_m3_s": 1},
    {"basis": "withdrawal", "policy_m3_h": -1},
])
def test_invalid_or_ambiguous_water(water):
    with pytest.raises(ValidationError):
        water_budget(water)


def test_hydrologic_margin_is_not_treated_as_available_source():
    with pytest.raises(ValidationError, match="水文余量"):
        water_budget({
            "basis": "withdrawal",
            "wue_l_per_kwh_it": 1.5,
            "river_m3_h": 100,
            "eco_m3_h": 20,
        })
